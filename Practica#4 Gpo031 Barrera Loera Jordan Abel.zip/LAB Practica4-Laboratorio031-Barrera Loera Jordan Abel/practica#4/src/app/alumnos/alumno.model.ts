export interface Alumno{
    id: string;
    nombre: string;
    edad: string;
    matricula: string;
    correo: string;
}
