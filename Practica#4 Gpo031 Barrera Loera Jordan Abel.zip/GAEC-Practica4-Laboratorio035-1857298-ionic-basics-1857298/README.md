# GAEC-Practica4-Laboratorio035-1857298
Primera práctica ionic
